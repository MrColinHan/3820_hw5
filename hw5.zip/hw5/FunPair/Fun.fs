

module Fun

open Absyn

(* Environment operations *)

type 'v env = (string * 'v) list

let rec lookup env x =
    match env with 
    | []          -> failwith (x + " undefined")
    | (y, v) :: r -> if x = y then v else lookup r x

(* A runtime value is an integer or a function closure *)

type value = 
  | Int of int
  | PairV of value * value
  | Closure of string * string * expr * value env   (* (f, x, fBody, fDeclEnv) *)

let oper i1 i2 op : value =  
  match op with
    | "*" -> Int (i1 * i2)
    | "+" -> Int (i1 + i2)
    | "-" -> Int (i1 - i2)
    | "=" -> if i1 = i2 then Int 1 else Int 0
    | "<" -> if i1 < i2 then Int 1 else Int 0
    | _   -> failwith ("unknown primitive " + op) 


let get1  (tup:expr) (env : value env) : value = 
  match tup with
  | Var x ->  
    match lookup env x with
      | PairV (e1, e2)  ->  e1
      | _     ->  failwith  "not retrievable unit"
  | _ ->  failwith  "not a variable"
     


let get2  (tup:expr) (env : value env) : value = 
  match tup with
  | Var x ->  
    match lookup env x with
      | PairV (e1, e2)  ->  e2
      | _     ->  failwith  "not retrievable unit"
  | _ ->  failwith  "not a variable"


let rec eval (e : expr) (env : value env) : value =
    match e with 
      | Pair (e1, e2) -> PairV (eval e1 env, eval e2 env)
      | CstI i -> Int i
      | CstB b -> if b then Int 1 else Int 0

      | Sel1 s1   ->  get1  s1  env
      | Sel2 s2   ->  get2  s2  env

      | Var x  ->
        match lookup env x with
        | Int i -> Int i 
        | PairV ( p1, p2 )  -> PairV ( p1, p2 )
        | _     -> failwith "eval Var"
    
      | Prim (op, e1, e2) -> 
        let i1 = eval e1 env in
        let i2 = eval e2 env in
        match i1 with
        | Int i1 -> match i2 with 
          | Int i2 ->
        (*match op with
        | "*" -> i1 * i2
        | "+" -> Int i1 + Int i2
        | "-" -> Int i1 - Int i2
        | "=" -> if Int i1 = Int i2 then Int 1 else Int 0
        | "<" -> if Int i1 < Int i2 then Int 1 else Int 0
        | _   -> failwith ("unknown primitive " + op)*)
            oper i1 i2 op
          | _   -> failwith "not integer"
        | _   -> failwith "not integer"
    
      | Let (x, e1, e2) -> 
        let v =  (eval e1 env) in
        let env2 = (x, v) :: env in
        eval e2 env2
    
      | If (e1, e2, e3) -> 
        let b = eval e1 env in
        match b with 
        | Int b ->
        if b <> 0 then eval e2 env else eval e3 env
    
      | Letfun (f, x, e1, e2) -> 
        let env2 = (f, Closure(f, x, e1, env)) :: env in
        eval e2 env2

      | Call (Var f, e) -> 
        let c = lookup env f in
        match c with
        | Closure (f, x, e1, fenv) ->
          let v =  (eval e env) in
          let env1 = (x, v) :: (f, c) :: fenv in
          eval e1 env1
        | _ -> failwith "eval Call: not a function"
    
      | Call _ -> failwith "eval Call: not first-order function"
    



(* Evaluate in empty environment: program must have no free variables: *)

let run e = eval e []



